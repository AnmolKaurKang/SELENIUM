package com.TestCases;

import java.io.IOException;
import java.util.List;

import objectsFactory.HomePage;
import objectsFactory.CameraPage;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;

public class Scenario1 extends BaseTest {

	HomePage ah;
	CameraPage sp;
	int j;

	@BeforeMethod()
	public void InitiializeObj() throws IOException {
		ah = new HomePage();
		sp = new CameraPage();
	}

	@Test
	public void T1() {

		Assert.assertEquals(true, ah.textBoxDisplayed());

		Assert.assertEquals(true, ah.SearchButton());

	}

	@Test

	public void T2_T3() throws IOException, InterruptedException {

		ah.EnterData("Echo dot");
		Thread.sleep(5000);
		List<WebElement> li = ah.ListObjects();

		for (WebElement lis : li) {
			{
				Assert.assertTrue(lis.getText().contains("echo dot"));

			}
		}
	}

	@Test
	public void T4() throws InterruptedException {
		sp = ah.Clickable();

		Assert.assertEquals(5, 6);
		// List<WebElement> li = sp.ListofObj();

		// int Num = li.size();
		// System.out.println(Num);

	}

}
