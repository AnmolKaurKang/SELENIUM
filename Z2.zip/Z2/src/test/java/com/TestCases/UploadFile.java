package com.TestCases;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Utils.Utility;

import objectsFactory.BasePage;
import objectsFactory.UploadFiles;

public class UploadFile extends BaseTest {
	UploadFiles f;
	@BeforeMethod
	public void Initialize()
	{ driver.get("https://easyupload.io/");
		f=new UploadFiles();
	}
	
 @Test
 public void Upload() throws  InterruptedException
 {
	Thread.sleep(10000);
	 f.ClickOnUploadFile();
   

 }
} 
