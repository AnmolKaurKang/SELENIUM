package com.TestCases;

import java.awt.List;
import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.*;

import objectsFactory.DirectSearchPage;
import objectsFactory.HomePage;
import objectsFactory.ObjectResultPage;

public class Scenario2 extends BaseTest {
	HomePage hp;
	DirectSearchPage dsp;
	ObjectResultPage orp;

	@BeforeMethod
	public void Initialize() throws IOException, InterruptedException {
		hp = new HomePage();
		dsp = hp.EnterDataDirectSearch("echo dot");
		Thread.sleep(5000);
		orp = dsp.ClickOnProduct();
		Thread.sleep(5000);
		orp.SwitchToCurrentWindow();

	}

	@Test
	public void T1()

	{

		Assert.assertTrue(orp.QuantityisDisplayed());
		System.out.println("choosing quantiy");
		orp.ChooseQuantity("2");
		System.out.println("validating the quantity");
		Assert.assertEquals(2, orp.validateQuantity());

	}

	@Test
	public void T2() throws InterruptedException {

		Assert.assertTrue(orp.WishListDisplayed());
		Assert.assertTrue(orp.AddToCArtisDisplayed());
		Assert.assertTrue(orp.BuyNowisDisplayed());
	}

	@Test
	public void T3() throws InterruptedException {
		java.util.List<WebElement> li = orp.numberCheckBoxes();
		System.out.println(li.size());
		for (WebElement Check : li) {
			Check.click();
		}
		Thread.sleep(6000);
		Assert.assertTrue(orp.SelectedCheckBox());

	}

}
