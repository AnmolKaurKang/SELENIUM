package com.TestCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import objectsFactory.BasePage;
import objectsFactory.DirectSearchPage;
import objectsFactory.HomePage;
import objectsFactory.ObjectResultPage;

public class Scenario3 extends BaseTest {

	HomePage hp;
	DirectSearchPage dsp;
	ObjectResultPage orp;
	SoftAssert as;

	@BeforeMethod
	public void Initialize() throws IOException, InterruptedException {
		hp = new HomePage();
		dsp = hp.EnterDataDirectSearch("echo dot");
		Thread.sleep(5000);
		orp = dsp.ClickOnProduct();
		Thread.sleep(5000);
		orp.SwitchToCurrentWindow();
		as = new SoftAssert();

	}

	@Test
	public void T1() throws InterruptedException

	{
		Assert.assertEquals(orp.AddToWishlistToolTip(), "Add to Wish List");
		Assert.assertEquals(orp.AddToCartToolTip(), "Add to Shopping Cart");

	}

}
