package com.TestCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import objectsFactory.AddToCart;
import objectsFactory.Cart;
import objectsFactory.DirectSearchPage;
import objectsFactory.HomePage;
import objectsFactory.ObjectResultPage;

public class Scenario4 extends BaseTest {
	HomePage hp;
	DirectSearchPage dsp;
	ObjectResultPage orp;
	SoftAssert as;
	AddToCart at;
	Cart c;

	@BeforeMethod
	public void Initialize() throws IOException, InterruptedException {
		hp = new HomePage();
		dsp = hp.EnterDataDirectSearch("echo dot");
		Thread.sleep(5000);
		orp = dsp.ClickOnProduct();
		Thread.sleep(5000);
		orp.SwitchToCurrentWindow();
		as = new SoftAssert();

	}

	@Test
	public void ValidateLabel() throws InterruptedException {
		orp.ClickAddToCart();
		Thread.sleep(5000);
		at = orp.ValidateDilogBox();
		Assert.assertTrue(at.ValidateText());
		Thread.sleep(5000);

	}

	@Test
	public void ValidateCount() throws InterruptedException {
		orp.ClickAddToCart();
		Thread.sleep(5000);
		at = orp.ValidateDilogBox();
		Assert.assertTrue(at.ValidateCount());
		Thread.sleep(5000);
	}

	@Test
	public void DeleteItems() throws InterruptedException {
		orp.ClickAddToCart();
		Thread.sleep(5000);
		at = orp.ValidateDilogBox();
		c = at.ClickonCart();
		c.ClickDropdown();
		Thread.sleep(5000);
		Assert.assertTrue(c.ValidateCartTotal());

	}

	@Test
	public void validatePrice() throws InterruptedException {
		String a = orp.returnPrice();
		String z[] = a.split(" ");
		String price1 = z[1].trim();
		orp.ClickAddToCart();
		Thread.sleep(5000);
		at = orp.ValidateDilogBox();
		String b = at.returnPrice();
		String x[] = b.split("₹");
		String price2 = x[1];
		Assert.assertEquals(price1, price2);
	}
}
