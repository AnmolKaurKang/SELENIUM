package com.TestCases;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ActionListener.Action;

import objectsFactory.BasePage;

public class z{
	
	static int i;
// public static Logger log=LogManager.getLogger(z.class.getName());
	
	/*@Test
	 * public void link()
	{ WebElement Footer=driver.findElement(By.id("navFooter"));
		List<WebElement>li=Footer.findElements(By.tagName("a"));
		System.out.println(li.size());
		for(WebElement name:li)
		{
			System.out.println(name.getText());
		}
	}
	
	}
	*/
	public static void Main(String [] args)
	{
		System.out.println("anol");
		if(i<100)
		 {
			 System.out.println(i);
			 i++;
			 Main(null);
		 }
	/*int a[]= {4,5,7,4,5,1,7,7,9,1} ;
	//get the occurance of these numbers
	//add them into ArrayList
	ArrayList<Integer> ab= new ArrayList<Integer> () ;
	int k=0;
	// we have to add first element in ArrayList
	for(int i=0;i<a.length;i++)
	{
		if(!ab.contains(a[i]))
		{
			
			ab.add(a[i]);	
			k++;
			}
		for(int j=i;j<a.length;j++)
		{
			if()
		}
	}*/
 
	
	
	}	
		}

	



