package objectsFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public abstract class BasePage2
{
	public static WebDriver driver;

	public BasePage2(WebDriver driver)
	{
		this.driver=driver;
	}
	
	protected abstract void click(By Locator);
	
	protected abstract void sendText(By Loactor);
	
	protected abstract Boolean isDisplayed(By Locator);

}