package objectsFactory;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ActionListener.Action;

public class UploadFiles extends BasePage {
Action a=new Action();
	@FindBy(className="dz-button")
	WebElement UploadOption;
	 @FindBy(className="modal-content")
	 WebElement DialogueBox;
	 
	 @FindBy(xpath="(//div[@class='row'] //div[@class='input-field col s12 right-align'])[1]")
	 WebElement UploadButton;
	 
	 
	public void UploadFiles()
	{
		PageFactory.initElements(driver, this);
	}
	public void ClickOnUploadFile()
	{ ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", UploadOption);
		a.click(driver, UploadOption);
	}
	public void ClickDialogueBox()
	{
		a.click(driver, DialogueBox);
	}
	public void ClickOnUploadButton()
	{
		a.click(driver, UploadButton);
	}
	
}
